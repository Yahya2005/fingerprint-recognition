import tkinter as tk
from tkinter import filedialog, messagebox
from tkinter import Label, Button
import numpy as np
from PIL import Image
import tensorflow as tf
from tensorflow.keras.applications import ResNet50
from tensorflow.keras.applications.resnet50 import preprocess_input
from sklearn.metrics.pairwise import cosine_similarity

# Load the ResNet50 model with pre-trained weights
def load_model():
    base_model = ResNet50(weights='imagenet', include_top=False, input_shape=(224, 224, 3))
    model = tf.keras.Sequential([
        base_model,
        tf.keras.layers.GlobalAveragePooling2D()
    ])
    return model

# Preprocess image for the model
def preprocess_image(image_path):
    try:
        img = Image.open(image_path).convert('RGB')
        img = img.resize((224, 224))  # ResNet50 expects 224x224 images
        img_array = np.array(img)
        img_array = np.expand_dims(img_array, axis=0)  # Add batch dimension
        img_array = preprocess_input(img_array)  # Preprocess for ResNet50
        return img_array
    except Exception as e:
        messagebox.showerror("Error", f"Failed to preprocess image: {e}")
        return None

# Extract features from an image
def extract_features(img_path, model):
    img_array = preprocess_image(img_path)
    if img_array is not None:
        features = model.predict(img_array)
        return features.flatten()  # Ensure the features are 1-D
    return None

# Compare two fingerprints
def compare_fingerprints(img1_path, img2_path, model):
    features1 = extract_features(img1_path, model)
    features2 = extract_features(img2_path, model)
    
    if features1 is not None and features2 is not None:
        # Compute cosine similarity
        similarity = cosine_similarity([features1], [features2])
        return similarity[0][0]
    return None

# Function to handle the comparison when the button is pressed
def on_compare_button_pressed():
    if not (file_path1 and file_path2):
        messagebox.showerror("Error", "Please select both fingerprint images.")
        return

    model = load_model()
    similarity_score = compare_fingerprints(file_path1, file_path2, model)
    
    if similarity_score is not None:
        # Display the similarity score
        messagebox.showinfo("Result", f"Similarity score: {similarity_score:.2f}")
    else:
        messagebox.showerror("Error", "Failed to compare images.")

# Function to open file dialog and select image
def open_file1():
    global file_path1
    file_path1 = filedialog.askopenfilename(filetypes=[("Image files", "*.tif;*.jpg;*.jpeg;*.png")])
    lbl_file1.config(text=file_path1.split('/')[-1])

def open_file2():
    global file_path2
    file_path2 = filedialog.askopenfilename(filetypes=[("Image files", "*.tif;*.jpg;*.jpeg;*.png")])
    lbl_file2.config(text=file_path2.split('/')[-1])

# Initialize the GUI
root = tk.Tk()
root.title("Fingerprint Comparison")

# File paths
file_path1 = ""
file_path2 = ""

# Create GUI elements
btn_load_file1 = Button(root, text="Load Fingerprint 1", command=open_file1)
btn_load_file2 = Button(root, text="Load Fingerprint 2", command=open_file2)
btn_compare = Button(root, text="Compare", command=on_compare_button_pressed)

lbl_file1 = Label(root, text="No file selected")
lbl_file2 = Label(root, text="No file selected")

# Place GUI elements
btn_load_file1.pack(pady=10)
lbl_file1.pack(pady=5)
btn_load_file2.pack(pady=10)
lbl_file2.pack(pady=5)
btn_compare.pack(pady=20)

# Start the Tkinter event loop
root.mainloop()
